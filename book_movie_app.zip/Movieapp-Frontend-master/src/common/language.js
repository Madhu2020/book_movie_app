let language = [{
    id:1,
    language: "Hindi"
  },
  {
    id:2,
    language: "English"
  },
  {
    id:3,
    language: "Kannada"
  },
  {
    id:4,
    language: "Tamil"
  },
  {
    id:5,
    language: "Telugu"
  }
]

export default language;